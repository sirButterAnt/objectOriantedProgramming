package furnitureFactorySimulation;
public interface IFurnitureFactorySimulation{
    public void runSimulation();
}