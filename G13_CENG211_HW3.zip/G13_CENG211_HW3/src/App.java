import furnitureFactorySimulation.FurnitureFactorySimulation;
public class App {
public static void main(String[] args) {
    FurnitureFactorySimulation simulation = new FurnitureFactorySimulation();
    simulation.runSimulation();
}
}
