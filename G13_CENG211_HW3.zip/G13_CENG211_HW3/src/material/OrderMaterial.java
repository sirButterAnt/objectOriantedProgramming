package material;

public class OrderMaterial {
    Material material;
    int quantity;

    public OrderMaterial(Material material, int quantity) {
        this.material = material;
        this.quantity = quantity;
    }
    
}
